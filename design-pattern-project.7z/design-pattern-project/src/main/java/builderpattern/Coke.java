package builderpattern;

public class Coke extends ColdDrink{

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "Coke";
	}

	@Override
	public float price() {
		// TODO Auto-generated method stub
		return 22.8f;
	}

	
	//1
	//2
		//3
	//0
	//Coke c = new COke();
	//c.name
	//c.price
	//c.packing()
}
