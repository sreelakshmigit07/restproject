package builderpattern;

public class Main {
		public static void main(String[] args) {
			MealBuilder mealBuilder = new MealBuilder();
			System.out.println("#### Veg Meal######");
			Meal vegMeal=  mealBuilder.prepareVegMeal();
			vegMeal.showItems();
			
			System.out.println("Total cost for veg :"+vegMeal.getCost());
			
			System.out.println("####Removing Pepsi######");
			Meal vegMealwithoutPepsi = mealBuilder.removeAnItem("Pepsi",vegMeal);
			vegMealwithoutPepsi.showItems();
			System.out.println("Total cost after removing Pepsi :"+ vegMealwithoutPepsi.getCost());
			
			
			System.out.println("####Removing Coke######");
			Meal vegMealwithoutCoke = mealBuilder.removeAnItem("COKE",vegMeal);
			vegMealwithoutCoke.showItems();
			
			System.out.println("Total cost after removing coke :"+ vegMealwithoutCoke.getCost());
			
			
			System.out.println("####Non-veg Meal######");
			Meal nonVegMeal = mealBuilder.prepareNonVegMeal();
			nonVegMeal.showItems();
			System.out.println("Total cost for non veg :"+nonVegMeal.getCost());
			
			
		}
}
