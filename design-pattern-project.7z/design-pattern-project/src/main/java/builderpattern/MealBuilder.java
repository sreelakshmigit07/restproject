	package builderpattern;

import java.util.List;

public class MealBuilder {
			public Meal prepareVegMeal() {
				Meal m = new Meal();
				m.addItem(new VegBurger());
				m.addItem(new Coke());
				m.addItem(new Pepsi());
				return m;
			}
			
			public Meal removeAnItem(String itemName, Meal vegMeal) {
				Meal m = new Meal();
				List<Item> allITems = vegMeal.getAllItems();
				for(Item item:allITems) {
					if(!item.name().equalsIgnoreCase(itemName)) {
						m.addItem(item);
					}
				}
				return m;
			}
			
			public Meal prepareNonVegMeal(){
				Meal m = new Meal();
				m.addItem(new ChickenBurger());
				m.addItem(new Pepsi());
				return m;
			}
	}
