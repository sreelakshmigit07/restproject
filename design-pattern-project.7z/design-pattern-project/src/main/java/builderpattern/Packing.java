package builderpattern;

public interface Packing {
	public String pack();
}
