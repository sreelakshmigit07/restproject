package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesignPatternProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DesignPatternProjectApplication.class, args);
		
		Payment p1 = Payment.getInstancePayment();
		p1.pay(2000, "Sreelakshmi");
		Payment p2 = Payment.getInstancePayment();
		p2.pay(1000, "Sree");
		Payment p3 = Payment.getInstancePayment();
		p3.pay(3000, "Lakshmi");
	}

}
