package com;

public class Payment {
	
	private static Payment payment;
	private Payment() {
		System.out.println("Payment project object");
	}
	public static Payment getInstancePayment() {
		if(payment== null)
				payment = new Payment();
		
		return payment;
	}
	public void pay(int amt,String account) {
		System.out.println("PAID:"+amt+" TO: "+account);
	}

}
