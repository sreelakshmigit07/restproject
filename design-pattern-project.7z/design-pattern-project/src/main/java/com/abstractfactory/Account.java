package com.abstractfactory;

public interface Account {
	
		public void sendCheque();
}
