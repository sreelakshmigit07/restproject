package com.abstractfactory;


public class AccountFactory extends AbstractFactory
{
	@Override 
	public Shape getShape(String shapeType){ return null; } 
	@Override 
	public Color getColor(String color) 
	{ 
		 
		// TODO Auto-generated method stub
				return null;
   }
	@Override
	public Account getAccount(String account) {
		if(account == null)
		{ 
			return null; 
		} 
		if(account.equalsIgnoreCase("CURRENT"))
		{ 
			return new CurrentAccount(); 
		} 
		else if(account.equalsIgnoreCase("LOAN"))
		{ 
			return new LoanAccount();
		}
		else if(account.equalsIgnoreCase("SAVINGS"))
		{ 
			return new SavingsAccount();
		}
		
		return null;
	}
	
}
