package com.abstractfactory;

public interface Color {
	void fill(); 
}