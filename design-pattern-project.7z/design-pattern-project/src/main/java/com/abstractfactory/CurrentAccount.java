package com.abstractfactory;

public class CurrentAccount implements Account{
	
	@Override
	public void sendCheque() {
		System.out.println("Inside CurrentAccount::sendCheque() method.Current account will recieve the cheque"); 
	}

}
