package com.abstractfactory;

public class LoanAccount implements Account{
	
	@Override
	public void sendCheque() {
		System.out.println("Inside LoanAccount::sendCheque() method.Loan account will recieve the cheque"); 
	}


}
