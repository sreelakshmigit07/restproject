package com.abstractfactory;

public class Main {
		public static void main(String[] args) {
			AbstractFactory abstractFactory1 = FactoryProducer.getFactory("SHAPE");
			
			Shape shape1 = abstractFactory1.getShape("CIRCLE");
			
			shape1.draw();
			
			AbstractFactory abstractFactory2 = FactoryProducer.getFactory("COLOR");
			
			Color c = abstractFactory2.getColor("BLUE");
			
			c.fill();
			
			//Write the code to invoke appropriate account type
			
			AbstractFactory abstractFactory3 = FactoryProducer.getFactory("ACCOUNT");
			
			Account accountL = abstractFactory3.getAccount("LOAN");
			
			accountL.sendCheque(); //Loan account will recieve the cheque
			
			AbstractFactory abstractFactory4 = FactoryProducer.getFactory("ACCOUNT");
			
			Account accountS = abstractFactory4.getAccount("SAVINGS");
			
			accountS.sendCheque(); //Savings account will recieve the cheque
			
			
			
		}
}
