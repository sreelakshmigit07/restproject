package com.abstractfactory;

public class SavingsAccount  implements Account{
	
	@Override
	public void sendCheque() {
		System.out.println("Inside SavingsAccount::sendCheque() method.Savings account will recieve the cheque"); 
	}


}