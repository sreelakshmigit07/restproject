package com.abstractfactory;

public interface Shape 
{ 
	void draw(); 
}