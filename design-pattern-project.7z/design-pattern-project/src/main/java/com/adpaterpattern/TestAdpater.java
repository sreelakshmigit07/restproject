package com.adpaterpattern;

public class TestAdpater {
	
	
	public static void main(String args[]) {
		Apple apple1 = new Apple();
		apple1.getAppleColor("RED");
		
		Orange orange = new Orange();
		orange.getOrangeColor("ORANGE");
		
		AppleAdapter adapter = new AppleAdapter(orange);
		adapter.getAppleColor("GREEN");
		adapter.getAppleColorr("PURPLE");
		
		
	}

}


 class Apple{
	public void getAppleColor(String color) {
		System.out.println("Apple color is : "+ color);
	}
	
}
 
 class Orange{
	 public void getOrangeColor(String color) {
			System.out.println("Orange color is : "+ color);
		}
 }
 
 class AppleAdapter extends Apple{
	 private Orange orange;
	 public AppleAdapter(Orange orange) {
		 this.orange = orange;
	 }
	 public void getAppleColorr(String color) {
		 orange.getOrangeColor(color);
	 }
 }
