package com.oracle.springtraining.coupling1.factory;

import com.oracle.springtraining.coupling1.interfacesolutions.Account;
import com.oracle.springtraining.coupling1.interfacesolutions.CreditcardAccount;
import com.oracle.springtraining.coupling1.interfacesolutions.CurrentAccount;
import com.oracle.springtraining.coupling1.interfacesolutions.LoanAccount;
import com.oracle.springtraining.coupling1.interfacesolutions.SavingsAccount;

public class AccountFactory {

	private Account account;
	public Account getPaymentObject(String accountType) {
		
		if(accountType.equals("S"))
			account = new SavingsAccount("S123");
		else if(accountType.equals("C"))
			account = new CurrentAccount("C123");
		else if(accountType.equals("L"))
			account = new LoanAccount("L123");
		else if(accountType.equals("CC"))
			account = new CreditcardAccount("CC123");
		
		return account;
	}
}
