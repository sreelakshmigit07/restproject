package com.oracle.springtraining.coupling1.interfacesolutions;

import com.oracle.springtraining.coupling1.factory.AccountFactory;

public class PaymentService {
	
	private Account account;
	
	public PaymentService(String accountType) {
		
		this.account = new AccountFactory().getPaymentObject(accountType);
		
	}
	public void pay(){
	
		System.out.println("Payment using tight coupling ->"+ this.account.getDetails());
	}
}
